---
name: 'Feature request '
about: Suggest an idea for gym-gazebo.
title: ''
labels: Feature Request
assignees: ''

---

**Robot**
Name of the robot. Provide a reference if the robot is not officially supported by gym-gazebo.

**Feature description**
Provide a detailed description about the feature you would like to have implemented in gym-gazebo.
