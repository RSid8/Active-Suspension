import gym
import rospy
import roslaunch
import time
import numpy as np
import os
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist
from geometry_msgs.msg import WrenchStamped
from tf.transformations import euler_from_quaternion
from sensor_msgs.msg import Imu
from math import asin, atan2, degrees
from gym import utils, spaces
from gym_gazebo.envs import gazebo_env
from std_srvs.srv import Empty
from gym.utils import seeding
#############################################################################################################################################################################################
class gazebo_lsd_v0(gazebo_env.GazeboEnv):

    def __init__(self):
        
        self.force_fl=0
        self.force_fr=0
        self.force_ml=0
        self.force_mr=0
        self.force_rl=0
        self.force_rr=0
        self.pitch=0
        self.roll=0
        self.yaw=0
        self.observation_space=np.zeros(8)
        self.orientation_list=[]
        self.action_space=np.zeros(0)
        self.obstacle_distance=0

        gazebo_env.GazeboEnv.__init__(self, "custom_world.launch")

        rospy.Subscriber("/fl_wheel_ft_sensor", WrenchStamped, self.callback_fl)
        rospy.Subscriber("/fr_wheel_ft_sensor", WrenchStamped, self.callback_fr)
        rospy.Subscriber("/ml_wheel_ft_sensor", WrenchStamped, self.callback_ml)
        rospy.Subscriber("/mr_wheel_ft_sensor", WrenchStamped, self.callback_mr)
        rospy.Subscriber("/rl_wheel_ft_sensor", WrenchStamped, self.callback_rl)
        rospy.Subscriber("/rr_wheel_ft_sensor", WrenchStamped, self.callback_rr)
        
        rospy.Subscriber("/imu", Imu, self.callback_imu)

        self.velocity_publisher=rospy.Publisher("/cmd_vel",Twist, queue_size=10)

        self.joint_1_publisher=rospy.Publisher("/lsd/joint1_position_controller/command", Float64,queue_size=10)
        self.joint_2_publisher=rospy.Publisher("/lsd/joint2_position_controller/command", Float64,queue_size=10)
        self.joint_3_publisher=rospy.Publisher("/lsd/joint3_position_controller/command", Float64,queue_size=10)
        self.joint_4_publisher=rospy.Publisher("/lsd/joint4_position_controller/command", Float64,queue_size=10)


        self.unpause = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        self.pause = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
        self.reset_proxy = rospy.ServiceProxy('/gazebo/reset_simulation', Empty)

        self.action_space = spaces.Box(4) 
        self.reward_range = (-np.inf, np.inf)

        self._seed()

    def callback_fl(self, msg):
        force_fl=msg.wrench.force
    def callback_fr(self, msg):
        force_fr=msg.wrench.force
    def callback_ml(self, msg):
        force_ml=msg.wrench.force
    def callback_mr(self, msg):
        force_mr=msg.wrench.force
    def callback_rl(self, msg):
        force_rl=msg.wrench.force
    def callback_rr(self, msg):
        force_rr=msg.wrench.force

    def callback_imu(self, msg):

        self.orientation_list=[msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w]
        (self.roll, self.pitch, self.yaw) = euler_from_quaternion(self.orientation_list)
        self.pitch=degrees(self.pitch)
        self.roll=degrees(self.roll)
        self.yaw=degrees(self.yaw)

    def get_observation(self):
        
        self.observation_space =np.array([self.force_fl, self.force_fr, self.force_ml, self.force_mr, self.force_rl, self.force_rr, self.pitch, self.roll])
        print(self.observation_space)

    def _seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def step(self, action):

        self.joint_1_publisher.publish(action[0])
        self.joint_2_publisher.publish(action[1])
        self.joint_3_publisher.publish(action[2])
        self.joint_4_publisher.publish(action[3])
        #publish till the action taken is completed
        self.done=False
        self.observation_= self.observation_space
        #condition to check if the episode is complete
        self.reward=0
        #compute reward due to the action taken   

        return observation, reward, done, {}

    def reset(self):

        rospy.wait_for_service('/gazebo/reset_simulation')
        try:
            #reset_proxy.call()
            self.reset_proxy()
        except (rospy.ServiceException) as e:
            print ("/gazebo/reset_simulation service call failed")

        # Unpause simulation to make observation
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            #resp_pause = pause.call()
            self.unpause()
        except (rospy.ServiceException) as e:
            print ("/gazebo/unpause_physics service call failed")

        state = self.get_observation

        return state