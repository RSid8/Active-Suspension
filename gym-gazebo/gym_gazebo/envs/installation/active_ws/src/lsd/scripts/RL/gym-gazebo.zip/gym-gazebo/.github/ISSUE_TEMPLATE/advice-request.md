---
name: Advice request
about: Ask for advice about your personal projects related to gym-gazebo.
title: ''
labels: help wanted
assignees: ''

---

**Robot**
Name of the robot. Provide a reference if the robot is not officially supported by gym-gazebo.

**Target**
Provide a detailed description about the goal of this feature/project.

**Desktop (please complete the following information):**
 - OS: [e.g. iOS]
 - ROS version [e.g. ROS2 Crystal]
 - Gazebo version [e.g. Gazebo 9.6.0]

**About you**
Name the organization your represent, if proceeds.
